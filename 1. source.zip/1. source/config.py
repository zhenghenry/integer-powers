Ltrian_cache = {}
Ltrian_complex_cache = {}
TriaN_cache = {}

def clear_cache():
	Ltrian_cache.clear()
	TriaN_cache.clear()